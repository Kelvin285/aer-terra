package kelvin.trewrite.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import kelvin.trewrite.main.resources.DistanceField;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Quaternion;
import net.minecraft.util.math.Vec3f;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vector4f;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.ChunkRegion;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.chunk.ChunkGenerator;

@Mixin(ChunkGenerator.class)
public class ChunkGeneratorMixin {
	
	@Inject(at = @At("HEAD"), method = "getWorldHeight", cancellable = true)
	public void getWorldHeight(CallbackInfoReturnable<Integer> info) {
		info.setReturnValue(512);
	}
	
	@Inject(at = @At("HEAD"), method = "generateFeatures", cancellable = true)
	public void generateFeatures(ChunkRegion region, StructureAccessor accessor, CallbackInfo info) {
		
		ChunkPos chunkPos = region.getCenterPos();
		BlockPos.Mutable pos = new BlockPos.Mutable();
		BlockPos.Mutable placing_pos = new BlockPos.Mutable();

		for (int x = chunkPos.getStartX(); x <= chunkPos.getEndX(); x++) {
			for (int z = chunkPos.getStartZ(); z <= chunkPos.getEndZ(); z++) {
				for (int y = region.getBottomY(); y <= region.getTopY(); y++) {
					GeneratePurityGrass(region, x, y, z, pos, placing_pos);
					GeneratePurityTrees(region, x, y, z, pos, placing_pos);
				}
				
			}
		}
		
		info.cancel();
	}
	
	private void GeneratePurityTrees(ChunkRegion region, int x, int y, int z, BlockPos.Mutable pos, BlockPos.Mutable placing_pos) {
		pos.set(x, y, z);
		if (region.getBlockState(pos).getBlock() == Blocks.GRASS_BLOCK) {
			if (region.getRandom().nextInt(100) == 0) {
				int height = region.getRandom().nextInt(8) + 8;
				BlockPos leaf_pos = pos.up(height);
				BlockPos leaf_pos_cone = pos.up(height - 3);
				BlockPos.Mutable testing_pos = new BlockPos.Mutable();
				
				boolean bare = region.getRandom().nextInt(50) == 0;
				
				//Quaternion rotation = new Quaternion(region.getRandom().nextInt(90)-45, region.getRandom().nextInt(90)-45, region.getRandom().nextInt(90)-45, true);
				Quaternion rotation = new Quaternion(45, 0, 0, true);

				Vec3f translation = new Vec3f();
				
				for (int X = -10; X < 10; X++) {
					for (int Y = 0; Y < 24; Y++) {
						for (int Z = -10; Z < 10; Z++) {
							placing_pos.set(X, Y, Z);
							translation.set(X, Y, Z);
							translation.rotate(rotation);
							
							testing_pos.set(x + (int)Math.floor(translation.getX()), y + (int)Math.floor(translation.getY()), z + (int)Math.floor(translation.getZ()));
							if (region.isChunkLoaded(placing_pos)) {
								
								if (DistanceField.Cylinder(testing_pos, pos, height, 1)) {
									if (region.getRandom().nextInt(10) == 0)
										region.setBlockState(placing_pos, Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.DISTANCE, 2), 0);
								}
								
								if (DistanceField.cone(testing_pos, pos, height, 1.5f)) {
									region.setBlockState(placing_pos, Blocks.OAK_LOG.getDefaultState(), 0);
								}
								
								if (!bare) {
									if (DistanceField.sphere(testing_pos, leaf_pos, 3) &&
											DistanceField.cone(testing_pos, leaf_pos_cone, 7, 4)) {
										if (region.getRandom().nextInt(10) < 9)
										region.setBlockState(placing_pos, Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.DISTANCE, 2), 0);
									}
								} else {
									if (DistanceField.sphere(testing_pos, leaf_pos, 2)) {
										if (region.getRandom().nextInt(10) == 0)
										region.setBlockState(placing_pos, Blocks.OAK_LOG.getDefaultState(), 0);
									}
								}
								
								
							}
						}
					}
				}
			}
		}
	}
	
	private void GeneratePurityGrass(ChunkRegion region, int x, int y, int z, BlockPos.Mutable pos, BlockPos.Mutable placing_pos) {
		pos.set(x, y, z);
		if (region.getBlockState(pos).getBlock() == Blocks.GRASS_BLOCK) {
			if (region.getRandom().nextInt(10) == 0) {
				placing_pos.set(x, y + 1, z);
				if (region.isChunkLoaded(placing_pos))
				region.setBlockState(placing_pos, Blocks.GRASS.getDefaultState(), 0);
			}
		}
	}
}
